## Instructions:
1. Open https://medlook.cyraalesha.repl.co/
2. Enter a picture of medicines that are in our database, find it here! (unfortunately we are only able to train it on a few medicine we have on hand)
3. Click upload and you're done!